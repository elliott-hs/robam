-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : robam
-- 
-- Part : #1
-- Date : 2017-02-06 12:12:02
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `robam_action`
-- -----------------------------
DROP TABLE IF EXISTS `robam_action`;
CREATE TABLE `robam_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `robam_action`
-- -----------------------------
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `robam_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `robam_action_log`;
CREATE TABLE `robam_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `robam_action_log`
-- -----------------------------
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `robam_action_log` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `robam_addons`
-- -----------------------------
DROP TABLE IF EXISTS `robam_addons`;
CREATE TABLE `robam_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `robam_addons`
-- -----------------------------
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_addons` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `robam_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `robam_attachment`;
CREATE TABLE `robam_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `robam_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `robam_attribute`;
CREATE TABLE `robam_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `robam_attribute`
-- -----------------------------
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `robam_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `robam_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `robam_auth_extend`;
CREATE TABLE `robam_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `robam_auth_extend`
-- -----------------------------
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
INSERT INTO `robam_auth_extend` VALUES ('', '', '');
